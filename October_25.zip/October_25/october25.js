function unhide_all_answers(){    
    var answers = ["q1answers", "q2answers", "q3answers"];
    for(var i = 0; i < answers.length; i++){
        var answer = document.getElementById(answers[i]);
        answer.style.display = "block";
    }
}

