function addOneToElement(string elem_id){
    
}