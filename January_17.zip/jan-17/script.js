//When button is submitted either 

//  1. Send an alert that it was not the right answer, as well as the 
//     passed parameter to let them know

// ~~~~~~~~~  OR ~~~~~~~~~

//  2. Process the next question by hiding the current one and unhiding the next (unless it's the last question)

function submit_answer(input_name, correct_answer_value, question_submit_id, alertMessage, isLast, next_id){
    
    //Get the user answer from the radio buttons and store the value in the var : user_answer_value
    var answer = document.getElementsByName(input_name);
    var user_answer_value;
    for(var i = 0; i < answer.length; i++){
        if(answer[i].checked){
            user_answer_value = answer[i].value;
        }
    }
    
    //If the user answer is the same as the correct answer,
    //Hide the current question's submit button, disable the radio buttons,
        //then if the question is no the last one:
        // unhide the next question,
        // ~~~~~~~~~  OR ~~~~~~~~~
        //congratulate the user for completing the quiz 
    
    if (user_answer_value != correct_answer_value){
        //Here the answer was incorrect
        alert(user_answer_value + alertMessage);
        return;
    } else {
        //Here the answer is correct
        
        //Hide and disable the current submit button
        document.getElementById(question_submit_id).disabled = true;
        document.getElementById(question_submit_id).style.visibility='hidden';
        
        //Look check to see if the question was the last one.
        if (isLast == "true") {
            alert("Thank you for taking my quiz!");
            return;
        }
        document.getElementById(next_id).style.display='block';
        //Unhide the next set of questions
    }
    
    
}