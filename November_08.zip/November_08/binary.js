function updateTotals(){
    var numDivs = 8;
    var totals_div_array = [];
    var values_div_array = [];
    for (i = 0; i < numDivs; i++){
        var tempTotalsDivName = "bin_total" + 2**i;
        totals_div_array.push(tempTotalsDivName);
        var tempValuesDivName = "bin_val" + 2**i;
        values_div_array.push(tempValuesDivName);
    }
    for (var i = 0; i < values_div_array.length; i++){
        var temp_bin_val_div_id = values_div_array[i];
        var temp_bin_val_div_elem_value = document.getElementById(temp_bin_val_div_id).innerHTML;
        var temp_bin_val_div_elem_int = parseInt(temp_bin_val_div_elem_value);
        if (temp_bin_val_div_elem_int == 1){  
            document.getElementById(totals_div_array[i]).innerHTML = 2**i;
        } else {
            document.getElementById(totals_div_array[i]).innerHTML = "0";
        }
    }    
}

function update_numbers(){
    var max = 255;
    var min = 0;
    var numDivs = 8;
    var inputNum = parseInt(document.getElementById("numberTracker").innerHTML);
    if (inputNum == max){
        return;
    } else if (inputNum == min){
        return;
    }
    var adder_div_array = [];
    for (i = 0; i < numDivs; i++){
        var tempValuesDivName = "bin_val" + 2**i;
        adder_div_array.push(tempValuesDivName);
    }
    var binString = decToBinary(inputNum);
    var j = binString.length -1;
    for (var i = 0; i < adder_div_array.length; i++){
        document.getElementById(adder_div_array[i]).innerHTML = binString.charAt(j);
        j--;
    }
    updateTotals();
}


function step(direction){
    var min = 0;
    var max = 255;
    enableBothButtons();
    if (direction == "back"){
        document.getElementById("numberTracker").innerHTML = parseInt(document.getElementById("numberTracker").innerHTML) - 1;
    } else if (direction == "forward"){
        document.getElementById("numberTracker").innerHTML = parseInt(document.getElementById("numberTracker").innerHTML) + 1;
    } else {
        return;
    }
    if (parseInt(document.getElementById("numberTracker").innerHTML) == max){
        disableButton("forward");
    } else if (parseInt(document.getElementById("numberTracker").innerHTML) == min){
        disableButton("back");
    }
    update_numbers();
}

function disableButton(id){
    document.getElementById(id).disabled = true;
}

function enableBothButtons()
{
    document.getElementById("back").disabled = false;
    document.getElementById("forward").disabled = false;
}


function clearNumbers(){
    document.getElementById("numberTracker").innerHTML = "0";
    document.getElementById("back").disabled = true;
    var numDivs = 8;
    var totals_div_array = [];
    var values_div_array = [];
    for (i = 0; i < numDivs; i++){
        var tempTotalsDivName = "bin_total" + 2**i;
        totals_div_array.push(tempTotalsDivName);
        var tempValuesDivName = "bin_val" + 2**i;
        values_div_array.push(tempValuesDivName);
    }
    for (var i = 0; totals_div_array.length; i++){
        document.getElementById(totals_div_array[i]).innerHTML = "0";
        document.getElementById(values_div_array[i]).innerHTML = "0";
    }

    update_numbers();
}

function decToBinary(n) 
{ 
    // array to store binary number 
    var binaryNum = []; 
    // counter for binary array 
    var i = 0; 
    while (n > 0) { 
        // storing remainder in binary array 
        binaryNum.push(n % 2); 
        n = Math.floor(n / 2); 
        i++; 
    }
    var binaryString = "";
    // printing binary array in reverse order 
    for (let j = i - 1; j >= 0; j--) {
        binaryString += binaryNum[j];
    }
    return binaryString;
} 

