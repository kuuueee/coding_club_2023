//These functions can be called anywhere in your html document, as long as the document makes a reference to the name of this file
//in this case it's november01.js such as:
//  <script src="november01.js"></script>

//Take the slide value, and apply it to the input, as well as change the innterHTML of the emojiPic div.
function adjustToSlideValues(){ 
    var sliderValue = document.getElementById("slider").value;
    document.getElementById("emojiInput").value = sliderValue;
    document.getElementById("emojiPic").innerHTML = "&#" + sliderValue + ";";
}

//This function executes when the slider is moved.
function moveFromSlider(){
    adjustToSlideValues();
    upDateInputFromSlider();
}

function updatePic(){
    document.getElementById("emojiPic").innerHTML = "&#" + document.getElementById("emojiInput").value + ";";
}

//This function executes when the slider is moved.
function updateNums(){
    convertToBinary();
    convertToHex();
}

function convertToBinary(){
    var numberToConvert = document.getElementById("numberInput").value;
    var convertedNumber = decToBinary(numberToConvert);
    document.getElementById("base2Input").value = convertedNumber;
    
}

function convertToHex(){
    var numberToConvert = document.getElementById("numberInput").value;
    var convertedNumber = decToHexa(numberToConvert);
    document.getElementById("base16Input").value = convertedNumber;
}

function decToBinary(n) 
{ 
    // array to store binary number 
    let binaryNum = new Array(32); 
  
    // counter for binary array 
    let i = 0; 
    while (n > 0) { 
  
        // storing remainder in binary array 
        binaryNum[i] = n % 2; 
        n = Math.floor(n / 2); 
        i++; 
    } 
    
    var binaryString = "";
    // printing binary array in reverse order 
    for (let j = i - 1; j >= 0; j--) {
        binaryString += binaryNum[j];
    }
    return binaryString;
} 

function decToHexa(n) 
{ 
    // char array to store hexadecimal number 
    var hexaDeciNum = Array.from({length: 100}, 
                      (_, i) => 0); 
  
    // counter for hexadecimal number array 
    var i = 0; 
    while (n != 0) { 
        // temporary variable to store remainder 
        var temp = 0; 
  
        // storing remainder in temp variable. 
        temp = n % 16; 
  
        // check if temp < 10 
        if (temp < 10) { 
            hexaDeciNum[i] =  
            String.fromCharCode(temp + 48); 
            i++; 
        } 
        else { 
            hexaDeciNum[i] =  
            String.fromCharCode(temp + 55); 
            i++; 
        } 
  
        n = parseInt(n / 16); 
    } 
    var hexString = "";
    for (j = i - 1; j >= 0; j--){
        hexString += hexaDeciNum[j];
    }
    return hexString;
}


function hmm() {
    
    var hexCode = document.getElementById("base16Input").value;
    if (hexCode.length == 6){
        document.getElementById("response").innerHTML = "";
        var hexstring = "#" + hexCode;
        document.getElementById("interesting").innerHTML = hexstring;
        document.getElementById("interesting").style.backgroundColor = "#" + hexCode;
    } else {
        document.getElementById("response").innerHTML = "Whoops, incorrect hex : " + hexCode;    
    }    
}