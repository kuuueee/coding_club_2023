function currency_exchange() {
	let currency_rate = [7777, 1234, 21, 5, 15, 20, 7];
	let currency_rate_description = ["Exchange 7777 Gooblies for 1 Smackaroonie", "Exchange 1234 Silver Foxes for 1 Looper Note", "Exchange 21 RichFlexes for 1 Shiny Sand Dollar", "Exchange 5 PennyQuarters for 1 Vbucks", "Exchange 15 TickleNickles for 1 PastaPound", "Exchange 20 dollarcoins for Firedimes", "Exchange 7 US Dollars for &#128176;"];
	let currency_1 = ["Gooblies" , "Silver Foxes", "RichFlexes", "PennyQuarters", "TickleNickles", "dollarcoins", "US Dollars"]
	let currency_2 = ["Smackaroonie", "Looper Notes", "Shiny Sand Dollar", "Vbucks", "PastaPound", "Firedimes", "&#128176;"]
	
	let random = getRandomInt(currency_rate.length);
	
	let input = document.getElementById("dollarAmount");
	let counter = document.getElementById("counter");
	var prev_counter_value = counter.innerHTML;
	let exchangeRate = document.getElementById("exchangeRate");
	let owed = document.getElementById("owed");
	let owed_value = input.value * currency_rate[prev_counter_value];
	let insert = document.getElementById("insert");
	
	
	input.value = 0;
	counter.innerHTML = random;
	
	exchangeRate.innerHTML = currency_rate_description[random];
	owed.innerHTML = "Here are " + owed_value + " " + currency_1[prev_counter_value];
	
	insert.innerHTML = "Insert " + currency_2[random];
	
}



function getRandomInt(max) {
  return Math.floor(Math.random() * max);
}