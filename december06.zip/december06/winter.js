function currency_exchange() {
    
    //Set 4 arrays with the position matching to each of the conversions parameters
	let currency_rate = [7777, 1234, 21, 5, 15, 20, 7];
	let currency_rate_description = ["Exchange 7777 Gooblies for 1 Smackaroonie", "Exchange 1234 Silver Foxes for 1 Looper Note", "Exchange 21 RichFlexes for 1 Shiny Sand Dollar", "Exchange 5 PennyQuarters for 1 Vbucks", "Exchange 15 TickleNickles for 1 PastaPound", "Exchange 20 dollarcoins for Firedimes", "Exchange 7 US Dollars for &#128176;"];
	let currency_1 = ["Gooblies" , "Silver Foxes", "RichFlexes", "PennyQuarters", "TickleNickles", "dollarcoins", "US Dollars"];
	let currency_2 = ["Smackaroonie", "Looper Notes", "Shiny Sand Dollar", "Vbucks", "PastaPound", "Firedimes", "&#128176;"];
	
    //Use our helper function to return a random integer within the bounds of the above arrays. 
	let random = getRandomInt(currency_rate.length - 1);
	
    //Get the values from the DOM
	let input = document.getElementById("dollarAmount");
    let input_value = document.getElementById("dollarAmount").value;
	let counter = document.getElementById("counter");
	var prev_counter_value = counter.innerHTML;
	let exchangeRate = document.getElementById("exchangeRate");
	let owed = document.getElementById("owed");
	let owed_value = input.value * currency_rate[prev_counter_value];
	let insert = document.getElementById("insert");

	input.value = 0;
	counter.innerHTML = random;
	exchangeRate.innerHTML = currency_rate_description[random];
	owed.innerHTML = "We took " + input_value + " in exchange for " + owed_value + " " + currency_1[prev_counter_value];
	insert.innerHTML = "Insert " + currency_2[random];
    
    if (isNaN(input_value)){
        owed.innerHTML = "Value supplied was not a number";
    }
	
}

function getRandomInt(max) {
  return Math.floor(Math.random() * max);
}